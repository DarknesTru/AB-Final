
var numeros=[1, 2 ,3. 4, 5];

var suma = 0;

for (var i =0; i < numeros.length; i++){

suma += numeros[i];}

console.log("la suma de los elementos es:" + suma );



var numeros=[ 10, 4, 9, 2, 15 ];

var numeroMayor = numeros[0];

for (var= i = 1; i<numeroMayor.length; i++) {
    if (numeros[i]> numeroMayor) {
        numeroMayor = numeros[i];
    }
}




var numeros= [10, 4, 9, 2, 15];

var numeroMenor = numeros[0];

for( var i=1; i<numeros.length; i++) {
    if(numeros[i]<numeroMenor) {
        numeroMenor = numeros[i]
    }
}

















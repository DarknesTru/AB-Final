/*
var cadena = "Hola mundo";


var longitudCadena = cadena.length;


var cadena1 "hola";
var cadena2"Mundo";
var resultado = var cadena1 + cadena2;


var posicion = cadena.indexOf("Mundo");


var subcadena = cadena.substring(5);


var comparacion = cadena1.localeCompare(codena2);
if (comparacion===0) {
    else
}

var cadenaMayusculas = cadena.toUpperCase("HOLA MUNDO");


var cadenaMinuscul  as = cadena.toLowerCase("hola mundo");


var CadenaSinEspacios = cadena.trim( Hola Mundo );


var NuevaCadena = cadena.replace("Mundo", "JavaScript");
var nuevaCadena = cadena.replace(/Mundo/g, "JavaScript");

*/  
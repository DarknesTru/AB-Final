alert("Bienvenido, antes de comenzar necesitamos comprobar tu identidad");
var nombre= prompt("Escribe tu nombre");
var DNI= prompt("Escribe tu DNI");
var mail= prompt("Hola "+nombre+" "+" "+"por favor, escribe tu email");
var pass= prompt("itroduce tu contraseña");
alert("Bienvenido, "+nombre)
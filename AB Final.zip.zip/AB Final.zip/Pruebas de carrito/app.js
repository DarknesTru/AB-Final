document.addEventListener("DOMContentLoaded", function () {
    const productosContainer = document.getElementById("productos");
    const carritoLista = document.getElementById("carrito-lista");
    const totalSpan = document.getElementById("total");

    // Ejemplo de productos
    const productos = [
        { id: 1, nombre: "Producto 1", precio: 20 },
        { id: 2, nombre: "Producto 2", precio: 30 },
        { id: 3, nombre: "Producto 3", precio: 25 },
    ];

    // Renderizar productos
    productos.forEach(producto => {
        const productoElement = document.createElement("div");
        productoElement.classList.add("producto");
        productoElement.innerHTML = `
            <h3>${producto.nombre}</h3>
            <p>Precio: ${producto.precio} pesos</p>
            <button onclick="agregarAlCarrito(${producto.id}, '${producto.nombre}', ${producto.precio})">Agregar al Carrito</button>
        `;
        productosContainer.appendChild(productoElement);
    });

    // Función para agregar al carrito
    window.agregarAlCarrito = function (id, nombre, precio) {
        const itemCarrito = document.createElement("li");
        itemCarrito.innerHTML = `${nombre} - ${precio} pesos <button onclick="eliminarDelCarrito(${id})">Eliminar</button>`;
        carritoLista.appendChild(itemCarrito);
        
        // Actualizar total
        actualizarTotal();
    };

    // Función para eliminar del carrito
    window.eliminarDelCarrito = function (id) {
        const itemCarrito = document.querySelector(`#carrito-lista li`);
        carritoLista.removeChild(itemCarrito);

        // Actualizar total
        actualizarTotal();
    };

    // Función para actualizar el total
    function actualizarTotal() {
        const itemsCarrito = document.querySelectorAll("#carrito-lista li");
        let total = 0;

        itemsCarrito.forEach(item => {
            const precio = parseInt(item.innerText.split("-")[1]);
            total += precio;
        });

        totalSpan.innerText = total;
    }

    // Función para comprar
    document.getElementById("comprar-btn").addEventListener("click", function () {
        alert("¡Gracias por tu compra!");
        carritoLista.innerHTML = "";
        totalSpan.innerText = "0";
    });
});ç
ç

